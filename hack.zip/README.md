 jangan di gunain buat kejahatan..
 dosa tanggung sendiri
